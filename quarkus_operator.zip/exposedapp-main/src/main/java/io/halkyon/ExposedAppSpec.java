package io.halkyon;

public class ExposedAppSpec {

    // Add Spec information here
    private String imageRef;

    public String getImageRef() {
        return imageRef;
    }

    public void setImageRef(String imageRef) {
        this.imageRef = imageRef;
    }
}
