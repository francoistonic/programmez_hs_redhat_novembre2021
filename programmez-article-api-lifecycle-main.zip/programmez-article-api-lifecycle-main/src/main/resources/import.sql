INSERT INTO fruits (id, name, origin) VALUES ('31e1c6c8-4d75-4753-918f-d026749e3743', 'Apple', 0);
INSERT INTO fruits (id, name, origin) VALUES ('cbc41087-40ff-44b6-a3bb-b88a47b49ffd', 'Grape', 1);
INSERT INTO fruits (id, name, origin) VALUES ('caa3f3cc-1428-4f40-a142-459ffb7f83b2', 'Orange', 2);
INSERT INTO fruits (id, name, origin) VALUES ('13fd84fc-745a-4676-ad9b-185082000652', 'Strawberry', 3);

