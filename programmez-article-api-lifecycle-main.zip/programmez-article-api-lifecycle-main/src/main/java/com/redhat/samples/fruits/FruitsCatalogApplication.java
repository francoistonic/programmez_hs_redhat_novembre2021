package com.redhat.samples.fruits;

/**
 * Fruits catalog application main class.
 * Optional but allows starting up additional services or bootstrap initializations.
 * @author laurent
 */
public class FruitsCatalogApplication {
}
